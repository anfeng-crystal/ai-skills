package devflg.cloudflg.appflg.plugin.form;

import java.util.EventObject;

import kd.bos.form.plugin.AbstractFormPlugin;

/**
 * 
 * @author liebin.zheng
 * @date 2023/11/20
 */
public class DemoFormPlugin extends AbstractFormPlugin {

	@Override
	public void click(EventObject evt) {
		super.click(evt);
	}

}
