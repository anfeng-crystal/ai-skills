package devflg.cosmic.debug.test;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;

import org.junit.Test;

import com.alibaba.dubbo.common.utils.NetUtils;

import io.netty.util.NetUtil;
import kd.cosmic.debug.tools.CosmicLauncher;

/**
 * 
 * @author liebin.zheng
 * @date 2024/02/01
 */
public class CosmicLauncherTest {
	
	@Test
	public void testGetCosmicHome() {
//		String dir = "D:\\git\\kddt\\cosmic-template\\code";
		String dir = "C:/Users/kingdee/kingdee/cosmic004";
		System.out.println(CosmicLauncher.getCosmicHome(dir));
	}
	
	@Test
	public void testGetLocalhost() {
		
		System.out.println(getLocalHostName());
	}
	
	@Test
	public void testGetLocalhost2() {
		
		System.out.println(getLocalHostName2());
	}
	
	private String getLocalHostName() {
		InetAddress localhost = null;
		try {
			localhost = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		return localhost == null ? "UnknownHost" : localhost.getHostAddress();
	}
	
	private String getLocalHostName2() {
		return NetUtils.getLocalHost();
	}

}
